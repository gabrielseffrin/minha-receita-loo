# looproject
object-oriented language discipline project - LOO

projeto em desenvolvimento para a disciplina de Linguagem Orientada a Objetos - LOO


o projeto em desenvolvimento consiste em um sistema web para inserção e consultas de receitas culinárias
