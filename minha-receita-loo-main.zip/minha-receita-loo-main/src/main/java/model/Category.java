package model;

public enum Category {
    SOBREMESA, PADARIA, CONFEITARIA
}